<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<div class="card text-center">
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-warning">Go somewhere</a>
  </div>
  
  <form class="d-flex" role="search">
    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success" type="submit">Search</button>
  </form>
  <!--searchbox -->
  <div class="container">
    <h2 class="text-center">Room Booking</h2>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <input type="date" id="checkinDate" class="form-control mb-2" placeholder="Check-in Date">
        </div>
        <div class="col-md-4">
            <input type="date" id="checkoutDate" class="form-control mb-2" placeholder="Check-out Date">
        </div>
        <div class="col-md-4">
            <input type="number" id="budget" class="form-control mb-2" placeholder="Budget">
        </div>
        <div class="col-md-12">
            <button class="btn btn-warning btn-block" onclick="searchRooms()">Search</button>
        </div>
        
    </div>
    <!-- <div id="searchResults" class="mt-4"></div> -->
</div>
</div>

</body>
</html>