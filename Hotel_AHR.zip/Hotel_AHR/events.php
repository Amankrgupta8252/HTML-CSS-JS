<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Document</title>
    <style>
        .eve_card{
            margin: 100px;
        }
        .card-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Adjust opacity as needed */
            opacity: 0; /* Initially hidden */
            transition: opacity 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .card-overlay-content {
            color: white;
        }

        .card:hover .card-overlay {
            opacity: 1; /* Show overlay on hover */
        }

        .eve_card{
            margin: 100px;
        }

       
    </style>
</head>
<body>

<!-- fixed-top -->

<?php include 'Navbar.php'; ?>

<!-- navbar -->
<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner.png" class="d-block w-100" alt="First Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>EVENTS</u></h1>
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner2.png" class="d-block w-100" alt="Second Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>EVENTS</u></h1>
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner3.png" class="d-block w-100" alt="Third Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>EVENTS</u></h1>
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- <hr color="cream" size="25"> -->

<?php //include 'scrolling.php'; ?>

<?php include 'search_box.php'; ?>

<?php include 'AK_ScrollItem.php' ?>



    <div class="eve_card">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <div class="col">
                <div class="card">
                    <img src="image/img_1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_2.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- second  -->
    <div class="eve_card">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <div class="col">
                <div class="card">
                    <img src="image/img_1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_2.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- third  -->
    <div class="eve_card">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <div class="col">
                <div class="card">
                    <img src="image/img_1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_2.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Repeat the above card markup for three more cards -->
            <div class="col">
                <div class="card">
                    <img src="image/img_1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                    <div class="card-overlay">
                        <div class="card-overlay-content">
                        <h5 class="card-title">Additional Info</h5>
                        <p class="card-text">Additional details here...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- footer -->
<?php 
include 'footer.php'; 
?>
<!-- footer -->

</body>
</html>