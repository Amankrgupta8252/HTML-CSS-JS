<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
    body {
      margin: auto;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      overflow: auto;
      animation: gradient 15s ease infinite;
      background-size: 400% 400%;
      background-attachment: fixed;
    }

    .navbar {
      background: transparent;
    }

    @keyframes gradient {
      0% {
        background-position: 0% 0%;
      }

      50% {
          background-position: 100% 100%;
      }

      100% {
          background-position: 0% 0%;
      }
    }

    .bg-dark {
      --bs-bg-opacity: 1;
      background-color: rgb(155, 155, 155);
    }

    .navbar-expand-lg .navbar-collapse {
      margin: 0px 0px 0px 50px;
    }

    .navbar-expand-lg .navbar-nav .nav-link {
      margin: 0px 20px;
    }

    .navbar-nav .nav-link:hover {
      color: #fff;
      background-color: rgba(255, 255, 255, 0.2);
      border-radius: 5px;
    }

    .dropdown-menu .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="Index_1.php">
      <u><i><b>Hotel Logo</b></i></u>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="HomeAHR.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="room.php">Rooms</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="About.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="events.php">Events</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="contact.php">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="6_logout.php">LogOut</a>
        </li>
      </ul> 
    </div>
  </div>
</nav>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.min.js"></script>
</body>
</html>
