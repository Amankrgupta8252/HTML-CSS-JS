<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard with Chart</title>
    <!-- Adding Chart.js library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
</head>
<body>
    <div class="row">
        <!-- Users Stats -->
        <div class="col-lg-8 col-md-12 col-sm-12 mb-4">
            <div class="card card-small">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Users</h6>
                </div>
                <div class="card-body pt-0">
                    <div class="row border-bottom py-2 bg-light">
                        <div class="col-12 col-sm-6">
                            <div id="blog-overview-date-range" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                                <input type="text" class="input-sm form-control" name="start" placeholder="Start Date" id="blog-overview-date-range-1">
                                <input type="text" class="input-sm form-control" name="end" placeholder="End Date" id="blog-overview-date-range-2">
                                <span class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="material-icons"></i>
                                    </span>
                                </span>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 d-flex mb-2 mb-sm-0">
                            <button type="button" class="btn btn-sm btn-white ml-auto mr-auto ml-sm-auto mr-sm-0 mt-3 mt-sm-0">View Full Report &rarr;</button>
                        </div>
                    </div>
                    <!-- Chart for Users -->
                    <canvas id="usersChart" class="blog-overview-users" style="max-width: 100% !important;"></canvas>
                </div>
            </div>
        </div>
        <!-- End Users Stats -->
        <!-- Users By Device Stats -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="card card-small h-100">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Users by device</h6>
                </div>
                <div class="card-body d-flex py-0">
                    <!-- Chart for Users by Device -->
                    <canvas id="deviceChart" class="blog-users-by-device m-auto"></canvas>
                </div>
                <div class="card-footer border-top">
                    <div class="row">
                        <div class="col">
                            <select class="custom-select custom-select-sm" style="max-width: 130px;">
                                <option selected>Last Week</option>
                                <option value="1">Today</option>
                                <option value="2">Last Month</option>
                                <option value="3">Last Year</option>
                            </select>
                        </div>
                        <div class="col text-right view-report">
                            <a href="#">Full report &rarr;</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

    <script>
        // Data for Users Chart
        const usersData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [{
                label: "Users",
                data: [65, 59, 80, 81, 56, 55, 40],
                fill: false,
                borderColor: "rgb(75, 192, 192)",
                tension: 0.1
            }]
        };

        // Data for Users by Device Chart
        const deviceData = {
            labels: ["Desktop", "Tablet", "Mobile"],
            datasets: [{
                label: "Users by Device",
                data: [300, 50, 100],
                backgroundColor: [
                    "rgba(255, 99, 132, 0.2)",
                    "rgba(54, 162, 235, 0.2)",
                    "rgba(255, 206, 86, 0.2)"
                ],
                borderColor: [
                    "rgba(255, 99, 132, 1)",
                    "rgba(54, 162, 235, 1)",
                    "rgba(255, 206, 86, 1)"
                ],
                borderWidth: 1
            }]
        };

        // Drawing Users Chart
        var usersCtx = document.getElementById('usersChart').getContext('2d');
        var usersChart = new Chart(usersCtx, {
            type: 'line',
            data: usersData
        });

        // Drawing Users by Device Chart
        var deviceCtx = document.getElementById('deviceChart').getContext('2d');
        var deviceChart = new Chart(deviceCtx, {
            type: 'bar',
            data: deviceData
        });
    </script>
</body>
</html>
