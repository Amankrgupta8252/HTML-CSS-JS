<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <style>
    /* Basic CSS for styling */
    
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    input[type="text"], input[type="email"], textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
    .error {
        color: red;
    }

    .contact_1 { 
    margin: 0% 3% 1% 5%;
    padding: 40px;
    border: 1px solid #808383;
    display: block;
    float: left;
    clear: both;
    width: 40% !important;
    height: auto !important;
}

.con_p{
    margin: 150px 40px;

}

</style>
</head>
<body>


<!-- fixed-top -->

<?php include 'Navbar.php'; ?>

<!-- navbar -->

<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="banner.png" class="d-block w-100" alt="First Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>CONTACT US</u></h1>
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="banner2.png" class="d-block w-100" alt="Second Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>CONTACT US</u></h1>
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="banner3.png" class="d-block w-100" alt="Third Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>CONTACT US</u></h1>
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- <hr color="cream" size="25"> -->


<?php //include 'scrolling.php'; ?>

<?php //include 'AK_scrollItem.php'; ?>

<br>


<div class="contact_1">
    <form class="" method="post" action="send.php">
        <h1>Contact Us</h1>
        Email: <br> <label><input type="email" name="email" value=""><br><br>
        Subject: <br><input type="text" name="subject"value=""><br><br>
        Message: <br><textarea name="message"value=""></textarea><br><br>
        <button type="submit" name="send">Send</button>
    </form>
</div>
    <div class="con_p">
        <font size="5" color="#737676;">
        <p>
            <span class="d-block"><b><u>Address</u></b></span>
            <span>821115 Sasaram, Bihar, India</span>
        </p>
        <p>
            <span class="d-block">Phone</span>
            <span>+91 8252339216</span>
        </p>
        <p>
            <span class= "d-block">Email</span>
            <span>agupta183@rku.ac.in</span>
        </p>
        </font>
    </div>


      <!-- footer -->
<?php 
include 'footer.php'; 
?>
<!-- footer -->
    
</body>
<script>
function validateForm() {
    var email = document.getElementById("email").value;
    var Subject = document.getElementById("Subject").value;
    var message = document.getElementById("message").value;
    var errorMessage = "";

    if (Subject.trim() == "") {
        errorMessage += "Subject is required.<br>";
    }

    if (Email.trim() == "") {
        errorMessage += "Email is required.<br>";
    } else {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            errorMessage += "Invalid email address.<br>";
        }
    }

    if (message.trim() == "") {
        errorMessage += "Message is required.<br>";
    }

    if (errorMessage !== "") {
        document.getElementById("error-message").innerHTML = errorMessage;
        return false;
    }

    return true;

}
</script>
</html>