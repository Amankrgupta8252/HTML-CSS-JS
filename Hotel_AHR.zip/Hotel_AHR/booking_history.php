<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Details</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
<?php include 'Navbar.php'; ?>
<br><hr>

<?php
// Check if email is provided in the URL parameters
if(isset($_GET['email'])) {
    $email = $_GET['email'];

    // Create a database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "hotel";

    // Establish connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to select data from the bookings table for the provided email
    $sql = "SELECT * FROM bookings WHERE email = '$email'";

    // Execute the query
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr>";
            echo "<th>Email</th>";
            echo "<th>First Name</th>";
            echo "<th>Last Name</th>";
            echo "<th>Check In Date</th>";
            echo "<th>Check Out Date</th>";
            echo "<th>Payment Method</th>";
            echo "</tr>";
            // Output data from the bookings table
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["firstName"] . "</td>";
                echo "<td>" . $row["lastName"] . "</td>";
                echo "<td>" . $row["checkInDate"] . "</td>";
                echo "<td>" . $row["checkOutDate"] . "</td>";
                echo "<td>" . $row["paymentMethod"] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No bookings found for the provided email.";
        }
    } else {
        echo "Query failed: " . $conn->error;
    }

    // Close the connection
    $conn->close();
} else {
    echo "Email not provided.";
}
?>
</body>
</html>
