 <?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    if ($role === 'admin') {
        $admin_email = "triunityhotel@gmail.com";
        $admin_password = "ahr11@8252";
        if ($email === $admin_email && $password === $admin_password) {
            $_SESSION['admin_username'] = $email;
            header("Location:admin/admin/");
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    } elseif ($role === 'user') {
        $sql = "SELECT * FROM ahr WHERE email = '$email' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            header("Location: Index_1.php");
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Invalid role selected.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>



    <title>Login</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 300px;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #666;
}

input[type="email"],
input[type="password"],
select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 16px;
}

input[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #4caf50;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

a {
    text-decoration: none;
    color: #4caf50;
    margin-top: 10px;
    display: block;
    text-align: center;
}

a:hover {
    color: #45a049;
}

p.error {
    color: red;
    text-align: center;
    margin-top: 10px;
}

    </style>
</head>
<body>
    <!-- navbar  -->

    <nav class="navbar navbar-expand-lg fixed-top bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <u><i><b>Hotel Logo</b></i></u>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Hotel.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="6_reg.php">Rooms</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="6_reg.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="6_reg.php">Events</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="6_reg.php">Contact Us</a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          SignUp/SignIn
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item active" href="#">Registration</a></li>
            <li><a class="dropdown-item active" href="#">LogIn</a></li>
            <!-- Add more dropdown items as needed -->
          </ul>
        </li>

      </ul> 
    </div>
  </div>
</nav>

<?php //include 'Navbar.php'; ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <h2>Login</h2>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <label for="role">Role:</label>
        <select id="role" name="role">
            <option value="admin">Admin</option>
            <option value="user">User</option>
        </select><br><br>
        <input type="submit" value="Login">
        <a href="6_reg.php">Registration</a>
        <a href="forget_password.php">forgot password</a>
    </form>
    <?php if(!empty($error)) { ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } ?>
</body>
</html>


<?php
// Close connection
$conn->close();
?>
