<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rooms</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        .container_AK {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .row_AK {
            display: flex;
            flex-wrap: wrap;
            margin: 0% 0% 0% 0%;
        }

        .col_AK {
            flex: 0 0 auto;
            padding: 15px;
            box-sizing: border-box;
        }

        .card_AK-container_AK {
            perspective: 1000px;
        }

        .card_AK {
            position: relative;
            width: 100%;
            height: 200px;
            transition: transform 0.8s;
            transform-style: preserve-3d;
        }

        .card_AK:hover {
            transform: rotateY(180deg);
        }

        .card_AK-front_AK,
        .card_AK-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
        }

        .card_AK-front_AK {
            background: #ffffff;
        }

        .card_AK-back {
            background: #f8f9fa;
            transform: rotateY(180deg);
        }

        .card_AK-content_AK {
            padding: 20px;
            color: #333;
            font-size: 16px;
        }

        .book-now-btn{
            color: white !important;
            background-color: #4caf50 !important;
            border-radius: 20px;
            margin-top: 10px;
            float: right;
        }


    </style>
</head>
<body>

<!-- fixed-top -->

<?php include 'Navbar.php'; ?>

<!-- navbar -->
<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner.png" class="d-block w-100" alt="First Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>ROOMS</u></h1>
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner2.png" class="d-block w-100" alt="Second Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>ROOMS</u></h1>
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner3.png" class="d-block w-100" alt="Third Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>ROOMS</u></h1>
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- <hr color="cream" size="25"> -->

<!-- <?php //include 'scrolling.php'; ?> -->

<?php include 'search_box.php'; ?>

<?php include 'AK_ScrollItem.php' ?>


<!-- jumbotron -->
    
    <h1 align="center">Rooms</h1>

    <div class="container_AK mt-3">
        <div class="row_AK">
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_1.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                    <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_3.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add more rows of cards similarly -->
        <div class="row_AK">
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_1.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_3.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add more rows of cards similarly -->

        <div class="row_AK">
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_1.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_2.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col_AK">
                <h2>Luxury Room</h2>
                <p>Our luxury room for you..</p>
                <div class="card_AK-container_AK">
                    <div class="card_AK">
                        <div class="card_AK-front_AK">
                            <img class="card_AK-img-top" src="image/img_3.jpg" alt="Card image" style="width:100%; height:100%;">
                        </div>
                        <div class="card_AK-back">
                            <div class="card_AK-content_AK">
                                <p>Price: $200 per night</p>
                                <p>Services:</p>
                                <ul>
                                    <li>Free Wi-Fi</li>
                                    <li>Mini-bar</li>
                                    <li>Room Service</li>
                                     <button class="book-now-btn" data-bs-toggle="modal" data-bs-target="#bookingModal">Book Now</button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add more rows of cards similarly -->

    </div>



    <!-- ndnfnfsngfvfnvf -->

    <div class="modal" id="bookingModal" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Book Room</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form id="bookingForm" action="booking.php" method="post" onsubmit="return validateForm()">

                <div class="mb-3">
                    
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                    <!-- <button type="submit">Submit</button> -->
                   
                </div>

                <div class="mb-3">
                  <label for="firstName" class="form-label">First Name</label>
                  <input type="text" name="firstName" class="form-control" id="firstName" required>
                </div>
                <div class="mb-3">
                  <label for="lastName" class="form-label">Last Name</label>
                  <input type="text" name="lastName" class="form-control" id="lastName" required>
                </div>
                <div class="mb-3">
                  <label for="checkInDate" class="form-label">Check-in Date</label>
                  <input type="date" name="checkInDate" class="form-control" id="checkInDate" required>
                </div>
                <div class="mb-3">
                  <label for="checkOutDate" class="form-label">Check-out Date</label>
                  <input type="date" name="checkOutDate" class="form-control" id="checkOutDate" required>
                </div>
                <div class="mb-3">
                  <label for="paymentMethod" class="form-label">Payment Method</label>
                  <select class="form-select" name="paymentMethod" id="paymentMethod" required>
                    <option value="">Select Payment Method</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="PayPal">PayPal</option>
                    <!-- Add more options for payment methods as needed -->
                  </select>
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      
      <script>
        function validateForm() {
          const firstName = document.getElementById('firstName').value;
          const lastName = document.getElementById('lastName').value;
          const checkInDate = document.getElementById('checkInDate').value;
          const checkOutDate = document.getElementById('checkOutDate').value;
          const paymentMethod = document.getElementById('paymentMethod').value;
          
          if (!firstName || !lastName || !checkInDate || !checkOutDate || !paymentMethod) {
            alert("Please fill out all fields.");
            return false;
          }
          
          return true;
        }
      </script>
    <!-- kjdnkndsff -->


      <!-- footer -->
<?php 
include 'footer.php'; 
?>
<!-- footer -->
</body>
</html>
