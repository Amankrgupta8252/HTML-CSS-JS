<?php
// Database connection
$con = mysqli_connect("localhost", "root", "", "hotel");

// Check connection
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if(isset($_POST['submit'])) {
    $email = $_POST['email'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $checkInDate = $_POST['checkInDate'];
    $checkOutDate = $_POST['checkOutDate'];
    $paymentMethod = $_POST['paymentMethod'];

    // Insert data into the bookings table
    $sql = "INSERT INTO bookings (email, firstName, lastName, checkInDate, checkOutDate, paymentMethod) 
            VALUES ('$email','$firstName', '$lastName', '$checkInDate', '$checkOutDate', '$paymentMethod')";
    $result = mysqli_query($con, $sql);

    if ($result) {
        echo "Booking saved successfully.<br>";
    } else {
        echo "Error: " . mysqli_error($con);
    }
}

// Check if email is provided in the URL parameters
if(isset($_GET['email'])) {
    $email = $_GET['email'];

    // Fetch booking details for the provided email
    $sql = "SELECT * FROM bookings WHERE email = 'agupta183@rku.ac.in'";
    $result = mysqli_query($con, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            echo "<table>";
            echo "<tr>";
            echo "<th>Email</th>";
            echo "<th>First Name</th>";
            echo "<th>Last Name</th>";
            echo "<th>Check In Date</th>";
            echo "<th>Check Out Date</th>";
            echo "<th>Payment Method</th>";
            echo "</tr>";
            // Output data from the bookings table
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["firstName"] . "</td>";
                echo "<td>" . $row["lastName"] . "</td>";
                echo "<td>" . $row["checkInDate"] . "</td>";
                echo "<td>" . $row["checkOutDate"] . "</td>";
                echo "<td>" . $row["paymentMethod"] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No bookings found for the provided email.";
        }
    } else {
        echo "Query failed: " . mysqli_error($con);
    }
} else {
    echo "Email not provided.";
}

// Close the database connection
mysqli_close($con);
?>
