<!-- jumbotron -->

<!-- End Example Code -->
<!-- <div class="AK_card">
  <div class="row row-cols-1 row-cols-md-3 g-4">
    <div class="col">
      <div class="card">
        <img src="gallery3.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="gallery4.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="gallery5.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    
  </div><br> 


  <div class="row row-cols-1 row-cols-md-3 g-4">
    <div class="col">
      <div class="card">
        <img src="room1.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="room2.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="room3.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    
    
  </div><br>


  <div class="row row-cols-1 row-cols-md-3 g-4">
    <div class="col">
      <div class="card">
        <img src="room4.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="room5.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="room6.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content.</p>
          <a href="#" class="btn btn-warning">Go somewhere</a>
        </div>
      </div>
    </div>
    
  </div>
</div>-->


<!-- devide web two part -->

<!-- <div class="AK_card_1">
  <div class="container-fluid">
    <div class="row">
      Left Part 
      <div class="col-md-6 bg-light">
        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4">
              <img src="room3.jpg" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
              </div>
            </div>
          </div>
        </div>

        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
              </div>
            </div>
            <div class="col-md-4">
              <img src="room1.jpg" class="img-fluid rounded-start" alt="">
            </div>
          </div>
        </div>

        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4">
              <img src="room3.jpg" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
              </div>
            </div>
          </div>
        </div>

        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4">
              <img src="room5.jpg" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4">
              <img src="room5.jpg" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
              </div>
            </div>
          </div>
        </div>
      </div>

       Right Part 

      <div class="col-md-6 bg-secondary text-light">
      <div class="Login_1">
        <h5 class="card-title text-center">Login</h5>
          <form>
            <div class="mb-3">
              <label for="email" class="form-label">Email address</label>
              <input type="email" class="form-control" id="email" placeholder="Enter email">
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" placeholder="Password">
            </div>
            <div class="d-grid gap-2">
              <button type="submit" class="btn btn-primary">Login</button>
            </div>
          </form>
          <br><br>

          <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="room5.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="room1.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="room3.jpg" class="d-block w-100" alt="...">
            </div>
          </div>
        </div>
      footer
        <div class="button_c">
            <button class="btn btn-warning btn-block" onclick="searchRooms()">More Information About Rooms and Prices</button>
        </div> 
      <div class="card text-bg-dark">
   <img src="https://previews.123rf.com/images/foodandmore/foodandmore1705/foodandmore170500090/77253581-panoramic-wide-organic-food-background-concept-with-full-frame-pile-of-fresh-vegetables-and-fruits.jpg" class="card-img" alt="..."> 
  <div class="card-img-overlay">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
    <p class="card-text"><small>Last updated 3 mins ago</small></p>
  </div>
</div>
      
      -->








      nav .navigation ul li a.active,
nav .navigation ul li a:hover
{
	color: #FDC93B;

}


hower css






      <!-- Navigation start -->
	<nav>
		<img src="img/logo.svg" class="logo" alt="">

		<div class="navigation">
			<ul>
				<i id="menu-close" class="fas fa-times"></i>
				<li><a href="index.php" class="">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="course-inner.php">Course</a></li>

				<li><a href="blog.php">Blog</a></li>
				<li><a href="logout.php">Logout</a></li>
				<link rel="stylesheet" href="validation.js">
			</ul>

			<img src="img/menu.png" id="menu-btn" alt="">
		</div>
	</nav>
	<!-- Navigation ends -->