<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Navbar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- css  -->
  <link rel="stylesheet" href="style.css">
  <!-- end css  -->
  <style>
    /* Custom styles for footer */
    .footer {
    background-color: #000;
    color: #9f9191;
    padding: 1px;
    font-size: 15px;
    font-family: Arial, sans-serif;
}

    .footer h5 {
      font-size: 20px;
      margin-bottom: 15px;
      color: #fff;
    }

    .footer ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .footer ul li {
      margin-bottom: 10px;
    }

    .footer .form-control {
      padding: 10px;
    }

    .footer .btn-primary {
      padding: 10px 20px;
    }

    .footer .app-logo {
      height: 30px;
      margin-right: 10px;
    }

    .container_AHR {
    margin: 50px 20px;
}
  </style>
</head>
<body>

<!-- Your website content goes here -->

<footer class="footer">
  <div class="container_AHR">
    <div class="row">
      <div class="col-md-3">
        <h5>About Us</h5>
        <ul>
          <li>About Us</li>
          <li>Terms & Conditions</li>
          <li>Privacy Policy</li>
        </ul>
      </div>
      <div class="col-md-3">
        <h5>Rooms</h5>
        <ul>
          <li>The Rooms & Suites</li>
          <li>About Us</li>
          <li>Contact Us</li>
        </ul>
      </div>
      <div class="col-md-3">
        <h5>Restaurant</h5>
        <ul>
          <li>Address:<br>198 West 21th Street, Suite 721<br>New York, NY 10016</li>
          <li>Phone:<br>(+1) 435 3533</li>
          <li>Email:<br>info@domain.com</li>
        </ul>
      </div>
      <div class="col-md-3">
        <h5>Contact</h5>
        <form action="mailto:info@domain.com" method="post" enctype="text/plain">
          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email">
          </div>
          <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea class="form-control" id="message" name="message" rows="3"></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Send</button>
        </form>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-md-12 text-center">
      <i class="fi fi-brands-instagram"></i>
      <i class="fi fi-brands-whatsapp"></i>
      <i class="fi fi-brands-facebook"></i>
        <!-- Add more app logos here -->
      </div>
    </div>
  </div>
</footer>

</body>
</html>
