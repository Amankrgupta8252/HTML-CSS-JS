<?php
session_start();
include 'config1.php'; // Include database configuration file

if (isset($_SESSION['username'])) {
    echo "Welcome " . $_SESSION['username'];

    if (isset($_POST['submit'])) {
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Your database connection code should be in config1.php
        $q = mysqli_query($con, "INSERT INTO ahr (fullname, email, password) VALUES ('$fullname','$email','$password')");

        if ($q) {
            echo "<br> 1 row Inserted";
        } else {
            echo "<br> Error: " . mysqli_error($con);
        }
    }
} else {
    header('Location: insert.php'); // Redirect to login page if session username is not set
    exit(); // Stop further execution
}
?>
<?php
// session_start();
// include 'config1.php'; // Include database configuration file

// if (isset($_SESSION['username'])) {
//     echo "Welcome " . $_SESSION['username'];

//     if (isset($_POST['submit'])) {
//         $fullname = $_POST['fullname'];
//         $email = $_POST['email'];
//         $password = $_POST['password'];

//         // Your database connection code should be in config1.php
//         $q = mysqli_query($con, "INSERT INTO ahr (fullname, email, password) VALUES ('$fullname','$email','$password')");

//         if ($q) {
//             echo "<br> 1 row Inserted";
//         } else {
//             echo "<br> Error: " . mysqli_error($con);
//         }
//     }
// } else {
//     header('Location: insert.php'); // Redirect to login page if session username is not set
//     exit(); // Stop further execution
// }
?>
