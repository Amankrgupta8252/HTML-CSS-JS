<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Navbar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  

  <style>
  </style>

</head>
<body>
 
<!-- fixed-top -->

<?php include 'Navbar.php'; ?>


<!-- navbar -->
<!-- scrolling image  -->

<!-- end scrolling image  -->

<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner.png" class="d-block w-100" alt="First Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>HOME</u></h1>
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner2.png" class="d-block w-100" alt="Second Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>HOME</u></h1>
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner3.png" class="d-block w-100" alt="Third Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>HOME</u></h1>
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- <hr color="cream" size="25"> -->


<div class="card text-center">
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-warning">Go somewhere</a>
  </div>
  
  <form class="d-flex" role="search">
    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success" type="submit">Search</button>
  </form>
  <!--searchbox -->
  <div class="container">
    <h2 class="text-center">Room Booking</h2>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <input type="date" id="checkinDate" class="form-control mb-2" placeholder="Check-in Date">
        </div>
        <div class="col-md-4">
            <input type="date" id="checkoutDate" class="form-control mb-2" placeholder="Check-out Date">
        </div>
        <div class="col-md-4">
            <input type="number" id="budget" class="form-control mb-2" placeholder="Budget">
        </div>
        <div class="col-md-12">
            <button class="btn btn-warning btn-block" onclick="searchRooms()">Search</button>
        </div>
        
    </div>
    <!-- <div id="searchResults" class="mt-4"></div> -->
</div>
</div>



<!-- End Example Code -->
<!-- devide web two part -->

<!-- devide web two part -->

<?php include 'AK_ScrollItem.php' ?>



<div class="Food_S">
<div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="image/room1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room3.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room4.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
</div>
</div>


<div class="Food_S">
<div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="image/room5.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room6.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
</div>
</div>

<div class="Food_S">
<div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="image/room3.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room4.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room5.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room6.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
</div>
</div>


<!-- footer -->

<?php include 'footer.php'; ?>

<!-- footer -->


</body>
</html>

