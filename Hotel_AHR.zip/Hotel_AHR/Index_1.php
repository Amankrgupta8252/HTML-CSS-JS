<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Navbar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- css  -->
  <!-- <link rel="stylesheet" href="style.css"> -->
<!-- end css  -->


</head>
<body>
<!-- fixed-top -->

<?php include 'Navbar.php'; ?>

<!-- navbar -->

<?php include 'scrolling.php'; ?>

<?php include 'search_box.php'; ?>

<!-- devide web two part -->

<?php include 'AK_ScrollItem.php' ?>


<div class="Food_S">
<div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="image/room6.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room3.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
</div>
</div>


<div class="Food_S">
<div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="image/room2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room3.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room6.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room5.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
</div>
</div>

<div class="Food_S">
<div class="row row-cols-1 row-cols-md-4 g-4">
  <div class="col">
    <div class="card">
      <img src="image/room4.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room3.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room2.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
  <div class="col">
    <div class="card">
      <img src="image/room1.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <div class="card-overlay">
        <div class="card-overlay-content">
          <h5 class="card-title">₹ 2199</h5>
          <p class="card-text">Additional details here...</p>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeat the above card markup for three more cards -->
</div>
</div>


<!-- footer -->
<?php 
include 'footer.php'; 
?>
<!-- footer -->

</body>
</html>