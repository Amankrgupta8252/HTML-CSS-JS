
<?php
// Create a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get data from Table 1 using Table 2's ID
$sql = "SELECT ahr.*, bookings.email AS booking_email 
        FROM ahr
        INNER JOIN bookings ON ahr.email = bookings.email
        WHERE bookings.email = 'agupta183@rku.ac.in'"; 

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data from Table 1
    while ($row = $result->fetch_assoc()) {
        echo "Email: " . $row["booking_email"] . "<br>";
        echo "First Name: " . $row["firstName"] . "<br>";
        echo "Last Name: " . $row["lastName"] . "<br>";
        echo "Check In Date: " . $row["checkInDate"] . "<br>";
        echo "Check Out Date: " . $row["checkOutDate"] . "<br>";
        echo "Payment Method: " . $row["paymentMethod"] . "<br>";
    }
} else {
    echo "No data found.";
}

$conn->close();
?>
