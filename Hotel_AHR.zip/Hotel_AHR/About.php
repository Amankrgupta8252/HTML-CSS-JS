<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .container3 {
            margin: 50px auto;
            max-width: 1200px; 
            position: relative; 
        }

        .img_fluid {
            width: 100%;
            border: 7px solid black; 
            border-radius: 50%;
        }

        .food_img {
            margin-left: -112px;
            margin-top: -206px;
            width: 40%;
            position: absolute;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
            border: 7px solid #f5efef;
            border-radius: 50%;
        }

        @media (max-width: 768px) {
            .food_img {
                width: 100%; 
                position: static; 
                transform: none; 
            }
        }
    </style>
</head>
<body>


<!-- fixed-top -->

<?php include 'Navbar.php'; ?>

<!-- navbar -->


<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner.png" class="d-block w-100" alt="First Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>ABOUT</u></h1>
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner2.png" class="d-block w-100" alt="Second Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>ABOUT</u></h1>
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="3000"> <!-- Adjusted interval to 3 seconds -->
      <img src="image/banner3.png" class="d-block w-100" alt="Third Slide">
      <div class="carousel-caption d-none d-md-block">
        <h1><u>ABOUT</u></h1>
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<!-- <hr color="cream" size="25"> -->





<!-- jumbotron -->

<section class="py-5 bg-light">
    <div class="container3">
        <div class="row align-items-center">
            <div class="col-md-12 col-lg-7 mb-5" data-aos="fade-up">
                <img src="image/img_1.jpg" alt="Image" class="img-fluid rounded">
            </div>
            <div class="col-md-12 col-lg-5 mb-5 position-relative" data-aos="fade-up">
                <img src="image/food-1.jpg" alt="Food Image" class="food_img">
                <h2 class="heading">Welcome!</h2>
                <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                <p><a href="#" class="btn btn-primary text-white py-2 mr-3">Learn More</a> <span class="mr-3 font-family-serif"><em>or</em></span> <a href="#"  data-fancybox class="text-uppercase letter-spacing-1">See video</a></p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>


</body>
</html>
