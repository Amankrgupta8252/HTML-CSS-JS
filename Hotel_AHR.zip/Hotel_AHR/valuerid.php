<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "hotel"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare data for insertion
$email = "dverma235@rku.ac.in"; // Example email
$password = "1234567890"; // Example password

// Hash the password for security (recommended)
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Prepare SQL INSERT statement
$sql = "INSERT INTO ahr (email, password) VALUES ('$email', '$password')";

// Execute SQL statement
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>
