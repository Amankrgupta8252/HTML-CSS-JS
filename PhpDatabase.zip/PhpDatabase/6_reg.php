<?php
session_start();
if(isset($_SESSION['username']))
{
    echo "Welcome Admin" . $_SESSION['username'];
?>
<form action="6_logout.php" method="post">
    <input type="submit" name="submit" value="Logout">
</form>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <script src="jquery-3.7.1.js"></script>
    <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>
</head>
<body>
    <center>
        <h1>Registration Details</h1>

        <form action="6_insert.php" method="post" id="form" enctype="multipart/form-data">

          Id: <input type="text" name="s_id"><br><br>

          Name: <input type="text" name="s_name"><br><br>

          Email: <input type="email" name="s_email"><br><br>

          Gender: <input type="radio" name="s_gender" value="Male">Male
          <input type="radio" name="s_gender" value="Female">Female
          <input type="radio" name="s_gender" value="Others">Other <br><br>
          
        Branch:<select name="s_branch">
            <!-- <option>----select----</option> -->
        <option value="CE">Computer</option>
        <option value="CV">Civil</option>
        <option value="ME">Mechanical</option>
        <option value="EE">Electrical</option><br>
</select><br><br>
Mobile: <input type="number" name="s_mobile"><br><br>
Photo: <input type="file" name="s_photo"><br><br>

<input type="submit" value="submit" name="submit">
        </form>
    </center>
    <script>
        $(document).ready(function(){
    $('#form').submit(function(login){
        login.preventDefault();
        var s_id = $('#s_id').val();
        var s_name = $('#s_name').val();
        var s_email = $('#s_email').val();
        var s_branch = $('#s_branch').val();
        var s_mobile = $('#s_mobile').val();
        $(".error").remove();
        if (s_name.length<3){
            $('#s_id').after('<span class="error">this field is required</span>');
        }
        if (last_name.length<3){
            $('#s_name').after('<span class="error">this field is required</span>');
        }
        if (last_name.length<3){
            $('#s_email').after('<span class="error">this field is required</span>');
        }
        if (last_name.length<3){
            $('#s_branch').after('<span class="error">this field is required</span>');
        }
    </script>
</body>
</html>
<?php
}
else
{
    header('location:6_index.php');
}
?>