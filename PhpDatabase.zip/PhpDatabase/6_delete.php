<?php
session_start();
if(isset($_SESSION['username']))
{
    echo "Welcome Admin" . $_SESSION['username'];
?>
<form action="6_logout.php" method="post">
    <input type="submit" name="submit" value="Logout">
</form>
<?php
$id = $_GET['id']; 

$con = mysqli_connect("localhost","root","","wp2024");

$q = mysqli_query($con , "delete from search_box where s_id = '$id'");

if($q){
    header('location:6_display.php');
}
else{
    echo "Error in delete operation";
}
?>
<?php
}
else
{
    header('location:6_index.php');
}
?>