<?php
session_start();
if(isset($_SESSION['username']))
{
    echo "Welcome Admin" . $_SESSION['username'];
?>
<form action="6_logout.php" method="post">
    <input type="submit" name="submit" value="Logout">
</form>
<!DOCTYPE html>
<?php
$id = $_GET['id'];
$con = mysqli_connect("localhost","root","","wp2024");
$ans = mysqli_query($con , "select * from search_box where s_id = '$id'");
$row = mysqli_fetch_array($ans);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <script src="jquery-3.7.1.js"></script>
    <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script> -->
</head>
<body>
    <center>
        <h1>Modify Details</h1>
        <form action="6_update.php" method="post" id="form" enctype="multipart/form-data">
          Id: <input type="text" name="s_id" value="<?php echo $row['s_id']; ?>"><br><br>
          Name: <input type="text" name="s_name" value="<?php echo $row['s_name']; ?>"><br><br>
          Email: <input type="email" name="s_email" value="<?php echo $row['s_email']; ?>"><br><br>
          
          Gender: <input type="radio" name="s_gender" value="Male" <?php if($row['s_gender']=='Male') { echo "checked";} ?>>Male

          <input type="radio" name="s_gender" value="Female" <?php if($row['s_gender']=='Female') { echo "checked";} ?>>Female

          <input type="radio" name="s_gender" value="Others" <?php if($row['s_gender']=='Others') { echo "checked";} ?>>Others <br><br>

        Branch:<select name="s_branch">
            <!-- <option>----select----</option> -->
        <option value="CE"
        <?php
        if($row['s_branch']=='CE')
        echo "selected";
        ?>
        >Computer</option>
        <option value="CV"<?php
        if($row['s_branch']=='CV')
        echo "selected";
        ?>
        >Civil</option>
        <option value="ME"<?php
        if($row['s_branch']=='ME')
        echo "selected";
        ?>
        >Mechanical</option>
        <option value="EE"<?php
        if($row['s_branch']=='EE')
        echo "selected";
        ?>
        >Electrical</option><br>
</select><br><br>

Mobile: <input type="number" name="s_mobile" value="<?php echo $row['s_mobile']; ?>"><br><br><br>

Photo: <input type="file" name="s_photo" value="<?php echo $row['s_photo']; ?>"> <?php echo $row['s_photo']; ?><br><br>

<input type="submit" value="Update" name="submit">
        </form>
    </center>
    <script>
        $(document).ready(function(){
    $('#form').submit(function(login){
        login.preventDefault();
        var s_id = $('#s_id').val();
        var s_name = $('#s_name').val();
        var s_email = $('#s_email').val();
        var s_branch = $('#s_branch').val();
        var s_mobile = $('#s_mobile').val();
        $(".error").remove();
        if (s_name.length<3){
            $('#s_id').after('<span class="error">this field is required</span>');
        }
        if (last_name.length<3){
            $('#s_name').after('<span class="error">this field is required</span>');
        }
        if (last_name.length<3){
            $('#s_email').after('<span class="error">this field is required</span>');
        }
        if (last_name.length<3){
            $('#s_branch').after('<span class="error">this field is required</span>');
        }
    </script>
</body>
</html>
<?php
}
else
{
    header('location:6_index.php');
}
?>