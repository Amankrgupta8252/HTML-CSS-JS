<?php
session_start();
if(isset($_SESSION['username']))
{
    echo "Welcome " . $_SESSION['username'];
?>
<form action="6_logout.php" method="post">
    <br>
    <input type="submit" name="submit" value="Logout">
</form>
<center>
    <form action="6_display.php" method="post">
    Search By Name: <input type="text" name="search"><br><br>
    <input type="submit" value="Search" value="search">
    </form>
    
<?php
$con = mysqli_connect("localhost","root","","wp2024");
$ans = mysqli_query($con, "select * from search_box order by s_id ASC");
?>
<style>
    table{
        margin:auto;
        color:black;
        /* border-color: aqua; */
        bottom:initial;
    }
</style>
<table>
<center>
    <h1>Details</h1>
    <table border="4">
        <tr>
            <th>s_id</th>
            <th>s_name</th>
            <th>s_email</th>
            <th>s_gender</th>
            <th>s_branch</th>
            <th>s_mobile</th>
            <th>s_photo</th>
            <th>Update</th>
            <th>Remove</th>
        </tr>
        <?php
        if(isset($_POST['search']))
        {
            $search = $_POST['search'];
            $ans = mysqli_query($con,"select * from search_box where s_name like '%$search%' ");
            while($row = mysqli_fetch_array($ans))
        { 
        ?>
<tr>
    <td><?php echo $row['s_id']; ?></td>
    <td><?php echo $row['s_name']; ?></td>
    <td><?php echo $row['s_email']; ?></td>
    <td><?php echo $row['s_gender']; ?></td>
    <td><?php echo $row['s_branch']; ?></td>
    <td><?php echo $row['s_mobile']; ?></td>
    <td>
        <img src="uploads/<?php echo $row['s_photo'] ?>" height="200%" width="200vh">
    </td>

    <td><a href="6_olddata.php?id=<?php echo $row['s_id']; ?>">Edit</a> </td>
    
    <td><a href="6_delete.php?id=<?php echo $row['s_id']; ?>">Delete</a> </td>
</tr>
<?php
    }
}
else
{
    $ans = mysqli_query($con,"select * from search_box");
    while($row = mysqli_fetch_array($ans))
{ 
?>
<tr>
<td><?php echo $row['s_id']; ?></td>
<td><?php echo $row['s_name']; ?></td>
<td><?php echo $row['s_email']; ?></td>
<td><?php echo $row['s_gender']; ?></td>
<td><?php echo $row['s_branch']; ?></td>
<td><?php echo $row['s_mobile']; ?></td>
<td>
<img src="uploads/<?php echo $row['s_photo'] ?>" height="200%" width="200vh">
</td>

<td><a href="6_olddata.php?id=<?php echo $row['s_id']; ?>">Edit</a> </td>

<td><a href="6_delete.php?id=<?php echo $row['s_id']; ?>">Delete</a> </td>
</tr>
<?php
}

}

?>
</table>
</center>
</center>
<?php
}
else
{
    header('location:6_index.php');
}
?>