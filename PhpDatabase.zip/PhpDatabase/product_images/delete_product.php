<?php
$con = new mysqli("localhost","root","","wp2024");
//Sql to delete a record
$sqldelete ="Delete from product_master where id=9";
if($con->query($sqldelete) == TRUE)
{
    echo "Record delete Successfully";
}else
{
    echo "Error deleteing record:" .$con->error;
}
?>
