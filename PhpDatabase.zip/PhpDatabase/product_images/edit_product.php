<?php
$con = new mysqli("localhost","root","","wp2024");
//Update Data in a MySQL Table
$sqlupdate = "update product_master set prod_name = 'Flipkart' where prod_id = 9";
if($con -> query($sqlupdate) == TRUE)
{
    echo "Edit product Successfully";
}
else
{
    echo "Error updating record: " . $con -> error;
} 
?>