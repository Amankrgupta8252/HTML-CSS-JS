<?php
session_start();
if(isset($_SESSION['username']))
{
    echo "Welcome Admin" . $_SESSION['username'];
?>
<form action="6_logout.php" method="post">
    <input type="submit" name="submit" value="Logout">
</form>
<?php
        // include 'config.php';
$con = mysqli_connect("localhost","root","","wp2024");

if(isset($_POST['submit'])){
    $s_id = $_POST['s_id'];
    $s_name = $_POST['s_name'];
    $s_email = $_POST['s_email'];
    $s_gender = $_POST['s_gender'];
    $s_branch = $_POST['s_branch'];
    $s_mobile = $_POST['s_mobile'];

    $q = mysqli_query($con,"select * from search_box where s_id = '$s_id' ");
    $row = mysqli_num_rows($q);
    if ($row>0)
    {
        echo "Student ID already exists";
    }
    else
    {

    if(!is_dir("uploads"))
    {
        mkdir("uploads");
    }
    $p_name = $_FILES['s_photo']['name'];
    $p_t_name = $_FILES['s_photo']['tmp_name'];
    $p_folder = "uploads/".$p_name;

    if(move_uploaded_file($p_t_name,$p_folder))
    {
        $q = mysqli_query($con, "insert into search_box 
        values('$s_id','$s_name','$s_email','$s_gender','$s_branch','$s_mobile','$p_name')");
        if($q){
            header('location:6_display.php');
        }else{
            echo "<br> Error";
        }
    }
    else
    {
        echo "Photo not uploaded";
    }
}
?>
<?php
}
else
{
    header('location:6_index.php');
}
}
?>