<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
</head>
<body>
    <center>
        <h1>Admin Login</h1>
        <br>
        <br>
        <form action="6_checklogin.php" method="post">
            Username:
            <input type="text" name="username"><br><br>
            Password:
            <input type="text" name="password"><br><br>
            <input type="submit" name="submit" value="Login">
        </form>
    </center>
</body>
</html>