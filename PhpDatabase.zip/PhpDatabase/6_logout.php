<?php
session_start();
if(isset($_SESSION['username']))
{
    echo "Welcome Admin" . $_SESSION['username'];
?>
<form action="6_logout.php" method="post">
<input type="btn" name="submit" value="Logout">
</form>
<?php
session_start();
session_destroy();
header('location:6_index.php');
?>
<?php
}
else
{
    header('location:6_index.php');
}
?>