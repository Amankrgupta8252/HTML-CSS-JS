<?php
session_start();
if(isset($_POST['submit']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username == 'admin' && $password == 'admin123')
    {
        $_SESSION['username'] = $username;
        header('location:6_reg.php');
    }
    else
    {
        echo "Username or Password are Wrong";
    }
}
?>